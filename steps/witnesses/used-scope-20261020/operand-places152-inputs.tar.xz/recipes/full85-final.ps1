$ErrorActionPreference='Stop'
$repo='C:/Nyasha_Planet/LMX';$base="$repo/buold_temp";$stage="$repo/build2/codex_places152_runtime_11";$out="$stage/full85_final02"
if(Test-Path -LiteralPath $out){throw 'Preserve final85 attempt'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
New-Item -ItemType Directory -Path "$out/old","$out/new" | Out-Null
. "$repo/tools/ps51_proc.ps1"
function Run152([string]$Tool,[string[]]$Argv,[string]$Log,[string]$Cwd){
 $saved=[Environment]::CurrentDirectory;Push-Location $Cwd
 try{[Environment]::CurrentDirectory=$Cwd;return Invoke-ProcBounded -Exe $Tool -Argv $Argv -TimeoutSec 180 -Log $Log}
 finally{[Environment]::CurrentDirectory=$saved;Pop-Location}
}
function Rebase152([string]$Text){
 if($Text -match '^[A-Za-z]:[/\\]'){$p=[IO.Path]::GetFullPath($Text);$prefix=[IO.Path]::GetFullPath("$repo/build")+'\';if($p.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){return "$base/"+$p.Substring($prefix.Length).Replace('\','/')}}
 return $Text
}
$inventory=Get-Content -LiteralPath "$base/codex_native122_values_03/inventory.json" -Raw | ConvertFrom-Json
$prefixRows=Get-Content -LiteralPath "$stage/full85_resume01/results.json" -Raw | ConvertFrom-Json
$prefixBuilds=Get-Content -LiteralPath "$stage/full85_resume01/builds.json" -Raw | ConvertFrom-Json
$oldPrefixRows=@($prefixRows|Where-Object {$_.Tier -eq 'old'})
$oldPrefixBuilds=@($prefixBuilds|Where-Object {$_.Tier -eq 'old'})
if($inventory.Count -ne 85 -or $oldPrefixRows.Count -ne 118 -or $oldPrefixBuilds.Count -ne 59){throw 'Exact85 corpus and completed59 baseline units required'}
$tiers=@(
 @{Name='old';Stage="$base/codex_operand_records_151";Compiler="$base/codex_operands151_build_06/l2trans.exe";Runtime="$base/codex_dispatch143_final_values_01/driver.o"},
 @{Name='new';Stage=$stage;Compiler="$stage/frontend-values-02/l2trans.exe";Runtime="$stage/actual-02/driver.o"}
)
$gcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe';$lib="$base/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o"
$rows=@();$builds=@();$u=0;$actualRuns=0;$retainedRuns=0;$freshC=0
foreach($case in $inventory){
 $bindingCounts=@{}
 foreach($tier in $tiers){
  if($tier.Name -eq 'old' -and $u -lt 59){
   $origin='full85';if($u -ge 31){$origin='full85_resume01'}
   $stem="$stage/$origin/old/unit$u";$known=@($oldPrefixBuilds|Where-Object Unit -eq $u)
   if($known.Count -ne 1){throw 'Ambiguous retained baseline unit'}
   foreach($pin in @(@{Ext='lm1';Hash=$known[0].GraphSha256},@{Ext='c';Hash=$known[0].CSha256},@{Ext='o';Hash=$known[0].ObjectSha256},@{Ext='exe';Hash=$known[0].ExeSha256})){
    if((Get-FileHash -LiteralPath "$stem.$($pin.Ext)").Hash -cne $pin.Hash){throw 'Retained executed baseline bytes changed'}
   }
   if((Get-FileHash -LiteralPath $tier.Compiler).Hash -cne $known[0].CompilerSha256 -or (Get-FileHash -LiteralPath $tier.Runtime).Hash -cne $known[0].RuntimeSha256){throw 'Retained baseline tool/runtime changed'}
   $bindingCounts.old=$known[0].MachineBindings;$builds+=$known[0]
   $oldRows=@($oldPrefixRows|Where-Object Unit -eq $u)
   if($oldRows.Count -ne 2){throw 'Baseline needs both terminal runs'}
   foreach($oldRow in $oldRows){if($oldRow.ActualExit -ne $oldRow.PriorExit -or ($oldRow.PriorSuccess -and -not $oldRow.Success)){throw 'Retained baseline has a regression'};$rows+=$oldRow;$retainedRuns++}
   continue
  }
  $stem="$out/$($tier.Name)/unit$u";$argv152=@($case.L2Args|ForEach-Object {Rebase152 $_});$argv152[$argv152.Count-1]="$stem.lm1";$cwd=Rebase152 $case.L2Cwd
  foreach($arg in $argv152){if($arg -match '\.lm2$' -and $arg -match '^[A-Za-z]:[/\\]' -and -not (Test-Path -LiteralPath $arg)){throw "Missing exact source: $arg"}}
  $flags=@('-pipe','-std=c99','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',"$($tier.Stage)/headers",'-I',"$base/codex_header98_source_control_06/includes",'-I',"$repo/build2/includes",'-I',$repo,'-I',"$repo/lm1/build",'-I',"$($tier.Stage)/src",'-I',$cwd,'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
  foreach($phase in @(
   @{Name='L2';Tool=$tier.Compiler;Args=$argv152;Cwd=$cwd},
   @{Name='L1';Tool="$repo/bin/l1trans.exe";Args=@("$stem.lm1","$stem.c");Cwd="$($tier.Stage)/src"},
   @{Name='COMPILE';Tool=$gcc;Args=($flags+@($case.Hooks)+@('-c',"$stem.c",'-o',"$stem.o"));Cwd="$($tier.Stage)/src"},
   @{Name='LINK';Tool=$gcc;Args=@("$stem.o",$tier.Runtime,$lib,'-Wl,--strip-debug','-o',"$stem.exe");Cwd="$($tier.Stage)/src"}
  )){
   $r=Run152 $phase.Tool $phase.Args "$stem.$($phase.Name).log" $phase.Cwd
   if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw "Actual $($tier.Name) unit$u $($phase.Name) failed"}
  }
  $freshC++;$bindings=@(Select-String -LiteralPath "$stem.lm1" -Pattern 'l2_entry_leaf\\native:.*l2_m[0-9]+_tr').Count;$bindingCounts[$tier.Name]=$bindings
  $build=@{Unit=$u;Tier=$tier.Name;Stem=$stem;L2Args=$argv152;L2Cwd=$cwd;GraphSha256=(Get-FileHash -LiteralPath "$stem.lm1").Hash;CSha256=(Get-FileHash -LiteralPath "$stem.c").Hash;ObjectSha256=(Get-FileHash -LiteralPath "$stem.o").Hash;ExeSha256=(Get-FileHash -LiteralPath "$stem.exe").Hash;CompilerSha256=(Get-FileHash -LiteralPath $tier.Compiler).Hash;RuntimeSha256=(Get-FileHash -LiteralPath $tier.Runtime).Hash;MachineBindings=$bindings}
  $builds+=$build;$builds | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/builds.json" -Encoding UTF8
  foreach($prior in $case.Rows){
   $r=Run152 "$stem.exe" @($prior.Args) "$stem.RUN$($rows.Count).log" "$out/$($tier.Name)"
   if(-not $r.Started -or $r.TimedOut){throw 'Actual terminal run required'}
   $actualRuns++;$ok=$r.Code -eq 0;if($prior.Success){$ok=$ok -and $r.Text -match ("l2_eternal_driver: "+$prior.Checks+" checks, 0 roots")}
   $rows+=@{Unit=$u;Tier=$tier.Name;Case=$prior.Case;Args=@($prior.Args);ActualExit=$r.Code;PriorExit=$prior.ActualExit;Success=$ok;PriorSuccess=$prior.Success;Checks=$prior.Checks;Diagnostic=$r.Text;ExeSha256=$build.ExeSha256;MachineBindings=$bindings;FreshStrictO2Unit=$true;FreshL2AndL1=$true;HistoricalExactArtifactReplay=$false}
   $rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/results.json" -Encoding UTF8
   if($prior.Success -and -not $ok){throw "Real value regression: $($tier.Name) unit$u $($prior.Case)"}
   if($r.Code -ne $prior.ActualExit){throw "Changed existing exit; inspect rather than rewrite oracle: $($tier.Name) unit$u $($prior.Case)"}
  }
 }
 if($bindingCounts.old -ne $bindingCounts.new){throw "Native eligibility changed at unit$u old=$($bindingCounts.old) new=$($bindingCounts.new)"}
 $u++;if($u%5 -eq 0){Write-Output "Final actual corpus: units=$u;new executions=$actualRuns;retained baseline executions=$retainedRuns;same oracles"}
}
$summary=@{Units=$u;FreshCUnitsThisAttempt=$freshC;ActualRunsThisAttempt=$actualRuns;RetainedTerminalBaselineRuns=$retainedRuns;CombinedObservedRuns=$rows.Count;NewActualRuns=@($rows|Where-Object Tier -eq 'new').Count;OldGreen=@($rows|Where-Object {$_.Tier -eq 'old' -and $_.Success}).Count;NewGreen=@($rows|Where-Object {$_.Tier -eq 'new' -and $_.Success}).Count;OldRed=@($rows|Where-Object {$_.Tier -eq 'old' -and -not $_.Success}).Count;NewRed=@($rows|Where-Object {$_.Tier -eq 'new' -and -not $_.Success}).Count;SameNativeEligibility=$true;FullKernelGate=$false;AllPathClosure=$false;FreshRelocated151Baseline=$true;RetainedBaselineRoots=@('full85','full85_resume01')}
$summary | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/summary.json" -Encoding UTF8
$summary | ConvertTo-Json -Depth 4
