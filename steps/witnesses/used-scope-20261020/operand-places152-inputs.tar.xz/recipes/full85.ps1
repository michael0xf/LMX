param([int]$StartUnit=0,[ValidatePattern('^full85[a-zA-Z0-9_-]*$')][string]$Label='full85',[string]$ContinueFrom='')
$ErrorActionPreference='Stop'
$repo='C:/Nyasha_Planet/LMX';$base="$repo/buold_temp";$stage="$repo/build2/codex_places152_runtime_11";$out="$stage/$Label"
if(Test-Path -LiteralPath $out){throw 'Preserve full85 attempt'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
New-Item -ItemType Directory -Path "$out/old","$out/new" | Out-Null
. "$repo/tools/ps51_proc.ps1"
function Run152([string]$Tool,[string[]]$Argv,[string]$Log,[string]$Cwd){
 $saved=[Environment]::CurrentDirectory;Push-Location $Cwd
 try{[Environment]::CurrentDirectory=$Cwd;return Invoke-ProcBounded -Exe $Tool -Argv $Argv -TimeoutSec 180 -Log $Log}
 finally{[Environment]::CurrentDirectory=$saved;Pop-Location}
}
function Rebase152([string]$Text){
 if($Text -match '^[A-Za-z]:[/\\]'){$p=[IO.Path]::GetFullPath($Text);$prefix=[IO.Path]::GetFullPath("$repo/build")+'\';if($p.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){return "$base/"+$p.Substring($prefix.Length).Replace('\','/')}}
 return $Text
}
$inventory=Get-Content -LiteralPath "$base/codex_native122_values_03/inventory.json" -Raw | ConvertFrom-Json
if($inventory.Count -ne 85){throw 'Exact85 corpus required'}
$tiers=@(
 @{Name='old';Stage="$base/codex_operand_records_151";Compiler="$base/codex_operands151_build_06/l2trans.exe";Runtime="$base/codex_dispatch143_final_values_01/driver.o"},
 @{Name='new';Stage=$stage;Compiler="$stage/frontend-values-02/l2trans.exe";Runtime="$stage/actual/driver.o"}
)
$gcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe';$lib="$base/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o"
$rows=@();$builds=@();$u=$StartUnit
if($StartUnit -gt 0){
 if($ContinueFrom -notmatch '^full85[a-zA-Z0-9_-]*$'){throw 'Explicit completed prefix required'}
 $rows=Get-Content -LiteralPath "$stage/$ContinueFrom/results.json" -Raw | ConvertFrom-Json
 $builds=Get-Content -LiteralPath "$stage/$ContinueFrom/builds.json" -Raw | ConvertFrom-Json
 if($rows.Count -ne $StartUnit*4 -or $builds.Count -ne $StartUnit*2){throw 'Only a fully executed prefix can be reused'}
 foreach($b in $builds){if($b.Unit -ge $StartUnit){throw 'Prefix contains an incomplete unit'}}
}
foreach($case in ($inventory|Select-Object -Skip $StartUnit)){
 $bindingCounts=@{}
 foreach($tier in $tiers){
  $stem="$out/$($tier.Name)/unit$u";$argv152=@($case.L2Args|ForEach-Object {Rebase152 $_});$argv152[$argv152.Count-1]="$stem.lm1";$cwd=Rebase152 $case.L2Cwd
  foreach($arg in $argv152){if($arg -match '\.lm2$' -and $arg -match '^[A-Za-z]:[/\\]' -and -not (Test-Path -LiteralPath $arg)){throw "Missing exact source: $arg"}}
  $flags=@('-pipe','-std=c99','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',"$($tier.Stage)/headers",'-I',"$base/codex_header98_source_control_06/includes",'-I',"$repo/build2/includes",'-I',$repo,'-I',"$repo/lm1/build",'-I',"$($tier.Stage)/src",'-I',$cwd,'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
  foreach($phase in @(
   @{Name='L2';Tool=$tier.Compiler;Args=$argv152;Cwd=$cwd},
   @{Name='L1';Tool="$repo/bin/l1trans.exe";Args=@("$stem.lm1","$stem.c");Cwd="$($tier.Stage)/src"},
   @{Name='COMPILE';Tool=$gcc;Args=($flags+@($case.Hooks)+@('-c',"$stem.c",'-o',"$stem.o"));Cwd="$($tier.Stage)/src"},
   @{Name='LINK';Tool=$gcc;Args=@("$stem.o",$tier.Runtime,$lib,'-Wl,--strip-debug','-o',"$stem.exe");Cwd="$($tier.Stage)/src"}
  )){
   $r=Run152 $phase.Tool $phase.Args "$stem.$($phase.Name).log" $phase.Cwd
   if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw "Actual $($tier.Name) unit$u $($phase.Name) failed"}
  }
  $bindings=@(Select-String -LiteralPath "$stem.lm1" -Pattern 'l2_entry_leaf\\native:.*l2_m[0-9]+_tr').Count;$bindingCounts[$tier.Name]=$bindings
  $build=@{Unit=$u;Tier=$tier.Name;L2Args=$argv152;L2Cwd=$cwd;GraphSha256=(Get-FileHash -LiteralPath "$stem.lm1").Hash;CSha256=(Get-FileHash -LiteralPath "$stem.c").Hash;ObjectSha256=(Get-FileHash -LiteralPath "$stem.o").Hash;ExeSha256=(Get-FileHash -LiteralPath "$stem.exe").Hash;CompilerSha256=(Get-FileHash -LiteralPath $tier.Compiler).Hash;RuntimeSha256=(Get-FileHash -LiteralPath $tier.Runtime).Hash;MachineBindings=$bindings}
  $builds+=$build
  $builds | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/builds.json" -Encoding UTF8
  foreach($prior in $case.Rows){
   $r=Run152 "$stem.exe" @($prior.Args) "$stem.RUN$($rows.Count).log" "$out/$($tier.Name)"
   if(-not $r.Started -or $r.TimedOut){throw 'Actual terminal run required'}
   $ok=$r.Code -eq 0;if($prior.Success){$ok=$ok -and $r.Text -match ("l2_eternal_driver: "+$prior.Checks+" checks, 0 roots")}
   $rows+=@{Unit=$u;Tier=$tier.Name;Case=$prior.Case;Args=@($prior.Args);ActualExit=$r.Code;PriorExit=$prior.ActualExit;Success=$ok;PriorSuccess=$prior.Success;Checks=$prior.Checks;Diagnostic=$r.Text;ExeSha256=$build.ExeSha256;MachineBindings=$bindings;FreshStrictO2Unit=$true;FreshL2AndL1=$true;HistoricalExactArtifactReplay=$false}
   $rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/results.json" -Encoding UTF8
   if($prior.Success -and -not $ok){throw "Real value regression: $($tier.Name) unit$u $($prior.Case)"}
   if($r.Code -ne $prior.ActualExit){throw "Changed existing exit; inspect rather than rewrite oracle: $($tier.Name) unit$u $($prior.Case)"}
  }
 }
 if($bindingCounts.old -ne $bindingCounts.new){throw "Native eligibility/body coverage changed: unit$u old=$($bindingCounts.old) new=$($bindingCounts.new)"}
 $u++;if($u%5 -eq 0){Write-Output "Actual dual corpus: units=$u;fresh C=$($builds.Count);runs=$($rows.Count);same exits and native binding counts"}
}
$summary=@{Units=$u;FreshCUnits=$builds.Count;ActualRuns=$rows.Count;OldGreen=@($rows|Where-Object {$_.Tier -eq 'old' -and $_.Success}).Count;NewGreen=@($rows|Where-Object {$_.Tier -eq 'new' -and $_.Success}).Count;OldRed=@($rows|Where-Object {$_.Tier -eq 'old' -and -not $_.Success}).Count;NewRed=@($rows|Where-Object {$_.Tier -eq 'new' -and -not $_.Success}).Count;SameNativeEligibility=$true;FullKernelGate=$false;AllPathClosure=$false;FreshRelocated151Baseline=$true}
$summary | ConvertTo-Json | Set-Content -LiteralPath "$out/summary.json" -Encoding UTF8
$summary | ConvertTo-Json
