
add_subdirectory(wavelibBoostTests) 

