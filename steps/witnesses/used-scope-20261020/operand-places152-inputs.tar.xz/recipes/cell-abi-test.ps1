param([ValidatePattern('^cell-abi-results-[0-9]+$')][string]$Label='cell-abi-results-02')
$ErrorActionPreference='Stop'
$repo='C:/Nyasha_Planet/LMX';$base="$repo/buold_temp";$stage="$repo/build2/codex_places152_runtime_11";$out="$stage/$Label"
if(Test-Path -LiteralPath $out){throw 'Preserve physical cell test attempt'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
New-Item -ItemType Directory -Path $out | Out-Null
. "$repo/tools/ps51_proc.ps1"
$flags=@('-pipe','-std=c99','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',$stage,'-I',"$stage/headers",'-I',"$base/codex_header98_source_control_06/includes",'-I',"$repo/build2/includes",'-I',$repo,'-I',"$repo/lm1/build",'-I',"$stage/src",'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
$gcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe'
$r=Invoke-ProcBounded -Exe $gcc -Argv ($flags+@("$stage/cell-abi-test.c","$stage/frontend-values-02/method-native.o","$base/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o",'-o',"$out/test.exe")) -TimeoutSec 180 -Log "$out/COMPILE.log"
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Strict physical-cell fixture compilation failed'}
$r=Invoke-ProcBounded -Exe "$out/test.exe" -Argv @() -TimeoutSec 60 -Log "$out/RUN.log"
@{Started=$r.Started;TimedOut=$r.TimedOut;Exit=$r.Code;Diagnostic=$r.Text;FixtureSha256=(Get-FileHash -LiteralPath "$stage/cell-abi-test.c").Hash;IncludedGeneratedRuntimeSha256=(Get-FileHash -LiteralPath "$stage/actual-02/driver.c").Hash;ExeSha256=(Get-FileHash -LiteralPath "$out/test.exe").Hash} | ConvertTo-Json | Set-Content -LiteralPath "$out/results.json" -Encoding UTF8
$r.Text
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0 -or $r.Text -notmatch 'physical152: [0-9]+ checks, 0 failures'){throw 'Physical cell fixture failed'}
