# Apply: общий вызов по контейнеру аргументов

Редакция: 22 ноября 2026 года. Клиент: [H01](../lmx/H01.lm3), [разбор](../../LMX_examples_and_analogies.ru.md#h01).

## Контракт общего ресивера

У LMX вход `args` — любая допустимая последовательность по @, включая плотный Array и обычную Structure/@[]. Штатный транспорт читает фактический тип каждого actual, без reinterpretation и предварительного boxing всей последовательности. Результат — запись с реальным типом. Передаются только присутствующие actuals; собственные defaults, required/private и точный результат выбранного callable сохраняются. FxKernel\attempt открывает штатное исполнение call/catch; библиотечное тело apply оборачивает полученный отказ в FxCallFailure.

Публичный ресивер `apply` уже входит в единое текущее ядро и используется прямо. Никаких import или выбираемых версий библиотек нет. Внутренние Fx/Rx-имена ниже обозначают структуры реализации ядра.

Этот документ показывает исходники общего ядрового механизма и локального процедурного приёма. Это разные области контракта, а не две взаимозаменяемые версии ядра: специализированный приём не подменяет весь общий API только потому, что он короче. Основной клиент выбирается отдельно из корректных вариантов по полной длине и границе учёта, см. H01.

## Полный алгоритм ресивера ядра LMX

Ниже приведено консервативное замыкание по корневым LMX-определениям от `FxApply`: полные определения перечислены один раз, включая те, которые упомянуты в генерируемом тексте тела. Это видимый исходник текущего ядра; он не подменяется строкой импорта. Общие определения повторно используются другими receivers; одинаковые определения не считаются новой самостоятельной реализацией для каждого клиента.

- [failures.lmx](../../LMX_Fn_Receivers/src/failures.lmx)
- [generic_runtime.lmx](../../LMX_Fn_Receivers/src/generic_runtime.lmx)

```lmx
FxThrows:
    adapter:
        FxArity
        FxIndex
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        SequenceSize
    call:
        FxCallFailure
        FxKernelFailure
        FxTypeToken
    capture:
        FxArity
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
        ReceiverIndex
        SequenceSize
    fixture:
        FxArity
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
    lazyfixture:
        FxArity
        FxIndex
        FxKernelFailure
        FxLazyCycle
        FxRecordArity
        FxTypeToken
    mutation:
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        SequenceElement
        SequenceSize
    mutationfixture:
        FxArity
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
        ReceiverIndex
        SequenceElement
        SequenceSize
    permutation:
        FxArity
        FxIndex
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        ReceiverPermutation
        SequenceSize
    predicate:
        FxCallFailure
        FxKernelFailure
        FxPredicate
        FxTypeToken
        ReceiverIndex
    rangefixture:
        FxArity
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
        SequenceSize
        SequenceStep
    recordcall:
        FxCallFailure
        FxKernelFailure
        FxRecordArity
        FxTypeToken
    reorder:
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        ReceiverPermutation
        SequenceSize
    retry:
        FxArity
        FxCallFailure
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
        ReceiverIndex
        SequenceSize
    selection:
        FxIndex
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        SequenceSize
    sequence:
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        SequenceSize
    sequencefixture:
        FxArity
        FxCallFailure
        FxIndex
        FxKernelFailure
        FxPredicate
        FxRecordArity
        FxShape
        FxTypeToken
        ReceiverIndex
        ReceiverPermutation
        SequenceElement
        SequenceSize
        SequenceStep
    snapshot:
        FxCallFailure
        FxIndex
        FxKernelFailure
        FxRecordArity
        FxTypeToken
        ReceiverIndex
        SequenceSize
    traversal:
        FxCallFailure
        FxKernelFailure
        FxTypeToken
        ReceiverIndex
        SequenceSize

FxTry:
    private:
        @: operation
        @: args
    return: @
    attempt:
        throws: FxKernelFailure FxTypeToken
        private: @: info FxKernel\signature(subject := operation)
        return: FxKernel\attempt(operation; args; info\throws)

FxApply:
    private:
        @: operation
        @: args
    return: @
    apply:
        throws: copy(FxThrows\call)
        private: @: outcome FxTry\attempt(operation := operation; args := args)
        if: outcome\ok = 0
            throw: FxCallFailure(outcome)
        return: outcome\value
```

Явная граница ядра: `FxKernel`, системные примитивы и стандартные вызовы, описанные в [KERNEL_REQUIREMENTS.md](../../LMX_Fn_Receivers/KERNEL_REQUIREMENTS.md). Это требуемые адаптеры к штатным операциям графа/вызова, а не показанный здесь C-код готового ядра. Их реализация не спрятана в цифре «размер библиотеки»: статус и условия приёмки приведены отдельно. Полный [собранный файл](../../LMX_Fn_Receivers/LMX_Receivers.lmx) и [экспорт имён](../../LMX_Fn_Receivers/src/public.lmx) находятся рядом.

## Реализация Haskell

Haskell apply полиморфен по a и b. У Haskell последовательная аппликация и каррирование уже являются механизмами языка; эта запись не заявляет отдельный динамический вектор аргументов. Клиентский сценарий одинаков: вызов выбранного действия и замена выбранной ссылки.

[Точный исходник модуля](../libraries/haskell/IntApply.hs):

```haskell
module IntApply (apply) where

apply :: (a -> b) -> a -> b
apply operation value = operation value
```

## Процедурный механизм сценария на том же ядре

Этот обычный пользовательский код показывает явный механизм конкретного сценария. Его int-специализация не является ограничением общего core-ресивера. Он не заменяет весь общий контракт ядра и не является старой библиотечной версией. У клиента он считается, если включён в его выбранный исходник; в таблице ниже его стоимость показана отдельно.

```lmx
Application:
    @: operation
    int: value
    return: int
    apply:
        return: operation(value)
```

## Размеры и границы сравнения

| Показанный код | Непробельные символы | Непустые строки | UTF-8 байты |
| --- | ---: | ---: | ---: |
| LMX: алгоритм и перечисленные LMX-зависимости | 1878 | 149 | 3135 |
| Haskell: весь показанный модуль | 79 | 3 | 99 |
| LMX: процедурный механизм сценария, отдельный контракт | 71 | 6 | 105 |

Это механические размеры показанных исходников. LMX строит обычные графовые callable с точными сигнатурами; Haskell пользуется собственным типовым и функциональным runtime. Таблица не утверждает равенства стоимости их ядер, минимальности замыкания зависимостей или одинаковой реализации. Реализация ядра показана отдельно от клиента. Исключать её из конкурентного клиентского сравнения допустимо при сопоставимом встроенном/библиотечном/операторном механизме у контроля, либо как естественный механизм языка без скрытого предметного алгоритма. Архитектуры не обязаны совпадать; поля, состояние, копии, идентичности и эффекты обязаны сохраняться. Сравнение по клиентам и исходные сохранённые хеши — в [functional_receiver_counts.json](../validation/functional_receiver_counts.json).

**Проверка:** текст, ссылки и размеры воспроизводятся [скриптом](../tools/update_receiver_comparisons.py). LMX и GHC здесь не запускались; подготовленные assertions в [Analogies.hs](../haskell/Analogies.hs) не являются receipt исполнения.
