module examples
