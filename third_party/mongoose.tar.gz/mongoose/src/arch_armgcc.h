#pragma once

#if MG_ARCH == MG_ARCH_ARMGCC
#ifndef _POSIX_TIMERS  // Some newlib builds, e.g. Espressif's, define it
#define _POSIX_TIMERS
#endif

#include <ctype.h>
#if !defined(MG_ENABLE_LWIP) || !MG_ENABLE_LWIP
#include <errno.h>
#endif
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#ifndef MG_PATH_MAX
#define MG_PATH_MAX 100
#endif

#endif
