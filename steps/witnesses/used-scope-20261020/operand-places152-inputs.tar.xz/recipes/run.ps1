param([ValidatePattern('^actual-[0-9]+$')][string]$Label='actual-02')
$ErrorActionPreference='Stop'
$taskRepo='C:/Nyasha_Planet/LMX';$taskBase="$taskRepo/buold_temp";$taskStage="$taskRepo/build2/codex_places152_runtime_11";$taskOut="$taskStage/$Label";$taskUnits="$taskStage/frontend-values-02"
if(Test-Path -LiteralPath $taskOut){throw 'Preserve actual runtime attempt'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
New-Item -ItemType Directory -Path $taskOut | Out-Null
. "$taskRepo/tools/ps51_proc.ps1"
function Run152([string]$Tool,[string[]]$Argv,[string]$Log,[string]$Cwd){
 $saved=[Environment]::CurrentDirectory;Push-Location $Cwd
 try{[Environment]::CurrentDirectory=$Cwd;return Invoke-ProcBounded -Exe $Tool -Argv $Argv -TimeoutSec 180 -Log $Log}
 finally{[Environment]::CurrentDirectory=$saved;Pop-Location}
}
foreach($phase in @(
 @{Name='HEADER';Args=@("$taskStage/src/l2src/lmx_value_owned.h.lm1","$taskStage/headers/l2src/lmx_value_owned.lm1.h")},
 @{Name='DRIVER';Args=@("$taskStage/src/l2_eternal_driver.lm1","$taskOut/driver.c")}
)){
 $r=Run152 "$taskRepo/bin/l1trans.exe" $phase.Args "$taskOut/$($phase.Name).log" "$taskStage/src"
 if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw "Runtime $($phase.Name) translation failed"}
}
$taskFlags=@('-pipe','-std=c99','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',"$taskStage/headers",'-I',"$taskBase/codex_header98_source_control_06/includes",'-I',$taskRepo,'-I',"$taskRepo/lm1/build",'-I',"$taskStage/src",'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
$taskGcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe'
$r=Run152 $taskGcc ($taskFlags+@('-c',"$taskOut/driver.c",'-o',"$taskOut/driver.o")) "$taskOut/driver.COMPILE.log" "$taskStage/src"
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Fresh strict O2 runtime compile failed'}
$rows=@()
foreach($mode in @('native','forced')){
 $exe="$taskOut/method-$mode.exe"
 $r=Run152 $taskGcc @("$taskUnits/method-$mode.o","$taskOut/driver.o","$taskBase/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o",'-Wl,--strip-debug','-o',$exe) "$taskOut/$mode.LINK.log" "$taskStage/src"
 if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'New runtime link failed'}
 foreach($root in @(0,1)){
  $args152=@('0','entry','7');$checks=13;if($root){$args152+=@('walkroot','1');$checks=17}
  $r=Run152 $exe $args152 "$taskOut/$mode.ROOT$root.log" "$taskStage/src"
  $success=$r.Started -and -not $r.TimedOut -and $r.Code -eq 0 -and $r.Text -match "l2_eternal_driver: $checks checks, 0 roots"
  $rows+=@{Mode=$mode;Root=$root;ActualExit=$r.Code;Success=$success;Diagnostic=$r.Text;DriverSourceSha256=(Get-FileHash -LiteralPath "$taskOut/driver.c").Hash;DriverObjectSha256=(Get-FileHash -LiteralPath "$taskOut/driver.o").Hash;UnitObjectSha256=(Get-FileHash -LiteralPath "$taskUnits/method-$mode.o").Hash;ExeSha256=(Get-FileHash -LiteralPath $exe).Hash;SourceL2Sha256=(Get-FileHash -LiteralPath "$taskBase/codex_places152_method_address_09.lm2").Hash;FullGate=$false}
  $rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$taskOut/results.json" -Encoding UTF8
  $r.Text
  if(-not $success){throw 'Actual native/walked method-slot value check failed'}
 }
}
Write-Output 'All4 actual runs passed; body-entry observation and wider gates still required'
