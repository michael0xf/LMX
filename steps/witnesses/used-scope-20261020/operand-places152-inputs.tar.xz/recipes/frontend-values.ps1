param([ValidatePattern('^frontend-values-[0-9]+$')][string]$Label='frontend-values-02')
$ErrorActionPreference='Stop'
$taskRepo='C:/Nyasha_Planet/LMX';$taskBase="$taskRepo/buold_temp";$taskStage="$taskRepo/build2/codex_places152_runtime_11";$taskOut="$taskStage/$Label"
if(Test-Path -LiteralPath $taskOut){throw 'Preserve candidate attempt'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
New-Item -ItemType Directory -Path $taskOut | Out-Null
. "$taskRepo/tools/ps51_proc.ps1"
function Run152([string]$Tool,[string[]]$Argv,[string]$Log,[string]$Cwd){
 $saved=[Environment]::CurrentDirectory;Push-Location $Cwd
 try{[Environment]::CurrentDirectory=$Cwd;return Invoke-ProcBounded -Exe $Tool -Argv $Argv -TimeoutSec 180 -Log $Log}
 finally{[Environment]::CurrentDirectory=$saved;Pop-Location}
}
$taskGcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe';$taskLib="$taskBase/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o"
$taskFlags=@('-pipe','-std=c99','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',"$taskStage/headers",'-I',"$taskBase/codex_header98_source_control_06/includes",'-I',$taskRepo,'-I',"$taskRepo/lm1/build",'-I',"$taskStage/src",'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
$taskHooks=@('-Dmain=l2_generated_main','-Dlmx_root_launch=l2_driver_root_launch','-Dlmx_merge_owned=l2_driver_merge_owned','-Dlmx_merge_profiles_owned=l2_driver_merge_profiles_owned','-Dlmx_merge_used_owned=l2_driver_merge_used_owned','-Dlmx_service_post=l2_driver_service_post')
$r=Run152 "$taskRepo/bin/l1trans.exe" @("$taskStage/src/l2src/l2trans.lm1","$taskOut/frontend.c") "$taskOut/frontend.L1.log" "$taskStage/src"
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Candidate frontend translation failed'}
$r=Run152 $taskGcc ($taskFlags+@('-O0',"$taskOut/frontend.c",$taskLib,'-o',"$taskOut/l2trans.exe")) "$taskOut/frontend.COMPILE.log" "$taskStage/src"
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Candidate frontend strict compile failed'}
$rows=@()
foreach($mode in @('native','forced')){
 $stem="$taskOut/method-$mode";$argv152=@();if($mode -eq 'forced'){$argv152+=@('--walk-methods')}
 $argv152+=@("$taskBase/codex_places152_method_address_09.lm2",'convert.lm2','primitive.lm2',"$stem.lm1")
 foreach($phase in @(
  @{Name='L2';Tool="$taskOut/l2trans.exe";Args=$argv152;Cwd="$taskBase/l2_harness/codex_consumer49_full_01/src"},
  @{Name='L1';Tool="$taskRepo/bin/l1trans.exe";Args=@("$stem.lm1","$stem.c");Cwd="$taskStage/src"},
  @{Name='COMPILE';Tool=$taskGcc;Args=($taskFlags+@('-O2','-fstrict-aliasing')+$taskHooks+@('-c',"$stem.c",'-o',"$stem.o"));Cwd="$taskStage/src"},
  @{Name='LINK';Tool=$taskGcc;Args=@("$stem.o","$taskStage/actual/driver.o",$taskLib,'-o',"$stem.exe");Cwd="$taskStage/src"}
 )){
  $r=Run152 $phase.Tool $phase.Args "$stem.$($phase.Name).log" $phase.Cwd
  if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw "Candidate $mode $($phase.Name) failed"}
 }
 foreach($root in @(0,1)){
  $argv152=@('0','entry','7');$checks=13;if($root){$argv152+=@('walkroot','1');$checks=17}
  $r=Run152 "$stem.exe" $argv152 "$stem.ROOT$root.log" "$taskStage/src"
  $success=$r.Started -and -not $r.TimedOut -and $r.Code -eq 0 -and $r.Text -match "l2_eternal_driver: $checks checks, 0 roots"
  $rows+=@{Mode=$mode;Root=$root;ActualExit=$r.Code;Success=$success;Diagnostic=$r.Text;CompilerSha256=(Get-FileHash -LiteralPath "$taskOut/l2trans.exe").Hash;SourceSha256=(Get-FileHash -LiteralPath "$taskBase/codex_places152_method_address_09.lm2").Hash;GeneratedL1Sha256=(Get-FileHash -LiteralPath "$stem.lm1").Hash;GeneratedCSha256=(Get-FileHash -LiteralPath "$stem.c").Hash;ExeSha256=(Get-FileHash -LiteralPath "$stem.exe").Hash;FullGate=$false}
  $rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$taskOut/results.json" -Encoding UTF8
  $r.Text
  if(-not $success){throw 'Candidate actual method-slot rebind/call failed'}
 }
}
Write-Output 'All4 actual read/write/address/rebind/call executions GREEN; wider gates and actual body counters still open'
