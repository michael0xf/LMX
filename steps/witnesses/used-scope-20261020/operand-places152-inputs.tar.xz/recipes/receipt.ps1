param([ValidatePattern('^receipt-[0-9]+$')][string]$Label='receipt-02')
$ErrorActionPreference='Stop'
$repo='C:/Nyasha_Planet/LMX';$base="$repo/buold_temp";$stage="$repo/build2/codex_places152_runtime_11";$old="$base/codex_operand_records_151"
$dest="$repo/steps/witnesses/used-scope-20261020";$out="$stage/$Label";$pack="$out/inputs"
if(Test-Path -LiteralPath $out){throw 'Preserve receipt attempts'}
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'No overlapping pipeline'}
New-Item -ItemType Directory -Path $pack | Out-Null
$utf8=[Text.UTF8Encoding]::new($false)
function Json152([string]$Path,$Value){[IO.File]::WriteAllText($Path,(($Value|ConvertTo-Json -Depth 12).Replace("`r`n","`n")+"`n"),$utf8)}
function Copy152([string]$Source,[string]$Relative){
 if([IO.Path]::GetFileName($Source) -ieq 'l2_driver_launch.err' -or [IO.Path]::GetFileName($Relative) -ieq 'l2_driver_launch.err'){throw 'Protected basename BEFORE IO'}
 $target=[IO.Path]::GetFullPath("$pack/$Relative");$root=[IO.Path]::GetFullPath($pack)+'\'
 if(-not $target.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)){throw 'Outside exact receipt root'}
 if(Test-Path -LiteralPath $target){if((Get-FileHash -LiteralPath $target).Hash -cne (Get-FileHash -LiteralPath $Source).Hash){throw 'Conflicting duplicate input'};return}
 New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
 Copy-Item -LiteralPath $Source -Destination $target
 if((Get-FileHash -LiteralPath $target).Hash -cne (Get-FileHash -LiteralPath $Source).Hash){throw 'Copied input changed'}
}
foreach($tree in @(@{Name='baseline151';Path=$old},@{Name='candidate152';Path=$stage})){
 $count=0
 foreach($dir in 'src','headers'){
  foreach($file in Get-ChildItem -LiteralPath "$($tree.Path)/$dir" -File -Recurse){
   if($file.Name -ieq 'l2_driver_launch.err'){continue}
   $rel=$file.FullName.Substring(([IO.Path]::GetFullPath($tree.Path)).Length+1).Replace('\','/')
   Copy152 $file.FullName "$($tree.Name)/$rel";$count++
  }
 }
 if($count -ne 281){throw 'Source closure must remain exactly281 files'}
}
$inventory=Get-Content -LiteralPath "$base/codex_native122_values_03/inventory.json" -Raw|ConvertFrom-Json
if($inventory.Count -ne 85){throw 'Exact85 inventory'}
foreach($case in $inventory){
 foreach($arg in $case.L2Args){
  if($arg -notmatch '\.lm2$'){continue}
  $source=$arg
  if($arg -notmatch '^[A-Za-z]:[/\\]'){$source=Join-Path $case.L2Cwd $arg}
  $source=[IO.Path]::GetFullPath($source);$prefix=[IO.Path]::GetFullPath("$repo/build")+'\'
  if($source.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){$rel=$source.Substring($prefix.Length).Replace('\','/');Copy152 "$base/$rel" "saved/$rel"}
  elseif($source.StartsWith(([IO.Path]::GetFullPath($repo)+'\'),[StringComparison]::OrdinalIgnoreCase)){$rel=$source.Substring(([IO.Path]::GetFullPath($repo)).Length+1).Replace('\','/');Copy152 $source "repository/$rel"}
  else{throw 'Unexpected source origin'}
 }
}
Copy152 "$base/codex_native122_values_03/inventory.json" 'saved/codex_native122_values_03/inventory.json'
foreach($dir in 'codex_consumer49_full_01','codex_impl56_public_focus_01'){
 foreach($name in 'convert.lm2','primitive.lm2','convert_impl.lm2'){Copy152 "$base/l2_harness/$dir/src/$name" "saved/l2_harness/$dir/src/$name"}
}
foreach($file in Get-ChildItem -LiteralPath "$base/codex_header98_source_control_06/includes" -Recurse -File){$rel=$file.FullName.Substring(([IO.Path]::GetFullPath("$base/codex_header98_source_control_06/includes")).Length+1).Replace('\','/');Copy152 $file.FullName "saved/codex_header98_source_control_06/includes/$rel"}
foreach($file in Get-ChildItem -LiteralPath "$repo/build2/includes" -Recurse -File){$rel=$file.FullName.Substring(([IO.Path]::GetFullPath("$repo/build2/includes")).Length+1).Replace('\','/');Copy152 $file.FullName "includes/$rel"}
$profiles=Get-Content -LiteralPath "$stage/profiles/results.json" -Raw|ConvertFrom-Json
foreach($profile in $profiles){Copy152 $profile.Source "fixtures/$([IO.Path]::GetFileName($profile.Source))"}
foreach($name in 'codex_address148_mixed_frame_01.lm2','codex_address148_mapped_frame_01.lm2','codex_hidden79_indexed_01.lm2','codex_paths149_offsets_01.lm2','codex_address148_foreign_frame_06.lm2','codex_address148_mixed_drop_01.lm2','codex_address148_mapped_drop_01.lm2','codex_paths149_offsets_drop_01.lm2','codex_places152_method_address_09.lm2'){
 Copy152 "$base/$name" "saved/$name"
}
foreach($name in 'levels','value'){Copy152 "$repo/dev/l2src_sandbox/tests/unit_array_binding_$($name)_refused.lm2" "fixtures/unit_array_binding_$($name)_refused.lm2"}
foreach($name in 'aux-values.ps1','profiles.ps1','full85-final.ps1','full85.ps1','frontend-values.ps1','run.ps1','observe.ps1','cell-abi-test.ps1','cell-abi-test.c','receipt.ps1'){
 Copy152 "$stage/$name" "recipes/$name"
}
Copy152 "$repo/tools/ps51_proc.ps1" 'recipes/ps51_proc.ps1'
# Standalone source evidence, not another installed compiler or maintained tree.
$pins=@()
foreach($file in Get-ChildItem -LiteralPath $pack -File -Recurse){
 if($file.Name -ieq 'l2_driver_launch.err'){throw 'Protected basename BEFORE IO'}
 $rel=$file.FullName.Substring(([IO.Path]::GetFullPath($pack)).Length+1).Replace('\','/')
 $pins+=@{Path=$rel;Bytes=$file.Length;Sha256=(Get-FileHash -LiteralPath $file.FullName).Hash}
}
Json152 "$out/input-manifest.json" $pins
$archive="$dest/operand-places152-inputs.tar.xz"
if(Test-Path -LiteralPath $archive){throw 'Preserve existing source archive'}
& tar.exe -cJf $archive -C $pack .
if($LASTEXITCODE -ne 0){throw 'Source archive failed'}
$verify="$out/unpacked";New-Item -ItemType Directory -Path $verify|Out-Null
& tar.exe -xJf $archive -C $verify
if($LASTEXITCODE -ne 0){throw 'Source archive extraction failed'}
foreach($pin in $pins){if((Get-FileHash -LiteralPath "$verify/$($pin.Path)").Hash -cne $pin.Sha256){throw 'Source archive roundtrip mismatch'}}
Copy-Item -LiteralPath "$out/input-manifest.json" -Destination "$dest/operand-places152-inputs.json"
$patch="$out/source.patch"
& git.exe -c core.autocrlf=false diff --no-index --no-ext-diff --unified=0 --output=$patch -- "$old/src" "$stage/src"
if($LASTEXITCODE -ne 1){throw 'Need the actual changed source patch'}
$text=[IO.File]::ReadAllText($patch).Replace('a/C:/Nyasha_Planet/LMX/buold_temp/codex_operand_records_151/src/','a/src/').Replace('b/C:/Nyasha_Planet/LMX/build2/codex_places152_runtime_11/src/','b/src/')
$text=$text.Replace('a/buold_temp/codex_operand_records_151/src/','a/src/').Replace('b/build2/codex_places152_runtime_11/src/','b/src/')
if($text -notmatch '--- a/src/l2src/' -or $text -match '(?m)^(---|\+\+\+) [ab]/[^s]'){throw 'Unexpected patch prefixes'}
[IO.File]::WriteAllText("$dest/operand-places152-u0.patch",$text.Replace("`r`n","`n"),$utf8)
$replay="$out/replay";Copy-Item -LiteralPath "$verify/baseline151" -Destination $replay -Recurse
& git.exe apply --unidiff-zero --unsafe-paths --directory=$replay "$dest/operand-places152-u0.patch"
if($LASTEXITCODE -ne 0){throw 'U0 source replay failed'}
foreach($pin in $pins|Where-Object Path -like 'candidate152/src/*'){
 $rel=$pin.Path.Substring('candidate152/'.Length)
 if((Get-FileHash -LiteralPath "$replay/$rel").Hash -cne $pin.Sha256){throw 'U0 replay differs from actual compiled sources'}
}
$records=@{}
foreach($name in 'full85_final02','aux-01','profiles','actual-02','observed-02','cell-abi-results-02','cross58'){
 $path="$stage/$name/results.json";$records[$name]=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
}
$records['corpus-builds']=Get-Content -LiteralPath "$stage/full85_final02/builds.json" -Raw|ConvertFrom-Json
$records['aux-builds']=Get-Content -LiteralPath "$stage/aux-01/builds.json" -Raw|ConvertFrom-Json
$records['refusals']=Get-Content -LiteralPath "$stage/aux-01/refusals.json" -Raw|ConvertFrom-Json
Json152 "$dest/operand-places152-results.json" $records
$receipt=@{
 State='Private152AddressProjectionAndPhysicalCellAccessVerifiedNotAllPathClosure';BaseMain='4b9fa159bbecb37fd155e13c242e7118bb98a6d3';Date='2026-10-22';Goal='active; unchanged full v3 objective';Candidate=$stage
 SnapshotFiles=281;InputFiles=$pins.Count;InputArchiveSha256=(Get-FileHash -LiteralPath $archive).Hash;InputArchiveRoundtripExact=$true;FiveSourceFileU0ReplayExact=$true
 FrontendSourceSha256=(Get-FileHash -LiteralPath "$stage/src/l2src/l2trans.lm1").Hash;FrontendCSha256=(Get-FileHash -LiteralPath "$stage/frontend-values-02/frontend.c").Hash;FrontendExeSha256=(Get-FileHash -LiteralPath "$stage/frontend-values-02/l2trans.exe").Hash
 RuntimeSourceSha256=(Get-FileHash -LiteralPath "$stage/actual-02/driver.c").Hash;RuntimeObjectSha256=(Get-FileHash -LiteralPath "$stage/actual-02/driver.o").Hash;ObservedRuntimeSha256=(Get-FileHash -LiteralPath "$stage/observed-02/driver.o").Hash
 L1CompilerSha256=(Get-FileHash -LiteralPath "$repo/bin/l1trans.exe").Hash;GccSha256=(Get-FileHash -LiteralPath 'C:/Qt/Tools/mingw1310_64/bin/gcc.exe').Hash;LibcObjectSha256=(Get-FileHash -LiteralPath "$base/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o").Hash
 Corpus=(Get-Content -LiteralPath "$stage/full85_final02/summary.json" -Raw|ConvertFrom-Json);Auxiliary=(Get-Content -LiteralPath "$stage/aux-01/summary.json" -Raw|ConvertFrom-Json)
 OwnedAssertions=398;MetadataAssertions=336;CommonIndexAssertions=420;DispatchAssertions=200;ReceivingAssertions=114;PhysicalCellAssertions=75;MethodAddressProductionRuns=4;MethodAddressObservedRuns=4;MethodObservedBodies=@{Native=@(0,1);Forced=@(2,3)}
 FailureHistory=@('Baseline151 method-address forced INVALID3 reproduced','Runtime-only11 removes INVALID but actual call remains RED93','Initial frontend attempt dedent error fixed before tests','Initial physical fixture count oracle failed because constructor writes; measured post-allocation delta instead','First85 attempt missing relocated harness header at31','Second85 attempt real unit58 regression; old/new unit x old/new runtime isolates runtime selector; fixed shared physical ABI, not Array consumer')
 HistoricalLargeBuildArtifactsDeletedByAuthor=$true;Historical151ManifestRehashedNow=$false;ResultsAreFreshRelocatedBaselineNotHistoricalBinaryReplay=$true;ProtectedBasenameNeverRead=$true
 AllPathClosure=$false;PublicDevIntegrated=$false;FullKernelGate=$false;SelfBuild=$false;Mail=$false
 ResultsSha256=(Get-FileHash -LiteralPath "$dest/operand-places152-results.json").Hash;InputsManifestSha256=(Get-FileHash -LiteralPath "$dest/operand-places152-inputs.json").Hash;SourcePatchSha256=(Get-FileHash -LiteralPath "$dest/operand-places152-u0.patch").Hash
}
Json152 "$dest/operand-places152-evidence.json" $receipt
$receipt|ConvertTo-Json -Depth 6
