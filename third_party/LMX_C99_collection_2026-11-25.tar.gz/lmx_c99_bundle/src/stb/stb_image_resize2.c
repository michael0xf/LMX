/* Build adapter; upstream header is unchanged. */
#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize2.h"
