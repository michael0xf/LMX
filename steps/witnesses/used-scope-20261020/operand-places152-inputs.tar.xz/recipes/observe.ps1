param([ValidatePattern('^observed-[0-9]+$')][string]$Label='observed-02')
$ErrorActionPreference='Stop'
$repo='C:/Nyasha_Planet/LMX';$base="$repo/buold_temp";$stage="$repo/build2/codex_places152_runtime_11";$out="$stage/$Label";$units="$stage/frontend-values-02"
if(Get-Process -Name gcc,cc1 -ErrorAction SilentlyContinue){throw 'One GCC pipeline'}
. "$repo/tools/ps51_proc.ps1"
$flags=@('-pipe','-std=c99','-O2','-fstrict-aliasing','-Wall','-Wextra','-Werror=implicit-function-declaration','-Werror=implicit-int','-Werror=incompatible-pointer-types','-Werror=discarded-qualifiers','-I',"$stage/headers",'-I',"$base/codex_header98_source_control_06/includes",'-I',$repo,'-I',"$repo/lm1/build",'-I',"$stage/src",'--param','ggc-min-heapsize=16384','--param','ggc-min-expand=20')
$gcc='C:/Qt/Tools/mingw1310_64/bin/gcc.exe'
$r=Invoke-ProcBounded -Exe $gcc -Argv ($flags+@('-c',"$out/driver.c",'-o',"$out/driver.o")) -TimeoutSec 180 -Log "$out/COMPILE.log"
if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Observed compile failed'}
$rows=@()
foreach($mode in @('native','forced')){
 $r=Invoke-ProcBounded -Exe $gcc -Argv @("$units/method-$mode.o","$out/driver.o","$base/l2_harness/codex_impl56_public_focus_01/gen/l2_libc.o",'-o',"$out/$mode.exe") -TimeoutSec 180 -Log "$out/$mode.LINK.log"
 if(-not $r.Started -or $r.TimedOut -or $r.Code -ne 0){throw 'Observed link failed'}
 foreach($root in @(0,1)){
  $argv152=@('0','entry','7');$expected=0;$checks=13;if($mode -eq 'forced'){$expected=2};if($root){$argv152+=@('walkroot','1');$expected++;$checks=17}
  $r=Invoke-ProcBounded -Exe "$out/$mode.exe" -Argv $argv152 -TimeoutSec 60 -Log "$out/$mode.ROOT$root.log"
  $bodies=[regex]::Matches($r.Text,'PLACES152 WALK_BODY').Count
  $ok=$r.Started -and -not $r.TimedOut -and $r.Code -eq 0 -and $bodies -eq $expected -and $r.Text -match "l2_eternal_driver: $checks checks, 0 roots"
  $rows+=@{Mode=$mode;Root=$root;ActualExit=$r.Code;ExpectedBodies=$expected;ActualBodies=$bodies;Success=$ok;Diagnostic=$r.Text;ExeSha256=(Get-FileHash -LiteralPath "$out/$mode.exe").Hash;RuntimeSha256=(Get-FileHash -LiteralPath "$out/driver.o").Hash}
  $rows | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$out/results.json" -Encoding UTF8
  $r.Text
  if(-not $ok){throw 'Observed actual values/body entries mismatch'}
 }
}
Write-Output 'Actual forced2/3 body entries, native0/1, all4 RUN0'
