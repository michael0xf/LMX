# Шаблоны проектирования на Lingvamyxa: 19–23

Русская версия. 21 ноября 2026 года.

Пять оставшихся шаблонов из списка 23: Singleton, Abstract Factory, Flyweight, Mediator и Interpreter. Первые восемнадцать описаны в предыдущих частях серии. Порядок учебный, а не рейтинг популярности. Архитектурная отправная точка — компактная реализация на Python; связанные методы LMX объединены общим DATA, а `demo` расположен рядом с ними.

Для каждого шаблона зафиксирован общий сценарий на LMX, Python, Java, C++, C#, TypeScript, Go и Rust. Полные листинги и измерения находятся в отдельных сравнительных файлах. Здесь приведены те же LMX-листинги и объяснение их работы.

## Правила чтения

Каждый пример — самостоятельная программа. DATA вызываемого кода — его фактический parent. Наличие общего поля не обязывает каждый метод группы его использовать. `@: selected method` сохраняет ссылку, `selected()` вызывает выбранный метод. Самостоятельный `fn`-контракт нужен только когда требуется отдельно описанная сигнатура.

Объявленный вход без начального значения может получить одноимённое значение непосредственного caller. Свободное имя без собственного объявления может обозначать его локальное место, допускающее изменение. Default не вытесняется автопередачей. Переданный alias сохраняет исходное место, а старый транзитивный fallback не превращает копию в alias. `private` закрывает неявное динамическое связывание в обе стороны; это не универсальный запрет явного доступа.

`node\` выбирает лексическое хранимое поле, а не parent. Явные пути используются для состояния, которое должно пережить отдельный вызов. `copy` и `merge` копируют исходный граф по своим контрактам; чтение локального значения и копирование хранимого графа различаются. Переданные слои данных задают настройки копии. Локальные значения активации сами по себе в копию не попадают.

Пустая строка закрывает весь корневой синтаксический блок. Вложенный `---` применяется только когда после закрытия вложенной структуры нужно продолжить внешнюю. Последний блок может закончиться на EOF.

[Правила связывания](../LMX_semantics.en.md#binding-places) · [Импорт](../LMX_semantics.en.md#import-receiver) · [Границы блоков](../LMX_grammar.en.md#levels) · [Контракт операндов](../LMX_semantics.en.md#operand-receiver)

**Копирование и потоки полей.** `import`, `copy` и `merge` в любом месте записи получают обычные аргументы в роли CODE. `copy` принимает один допущенный источник, `merge` — не меньше двух; оба выдают поток полей. Когда нужен один объект, поток явно собирается в группу: `(copy(Product))` или `(merge(Model Settings))`. Текущая принимающая структура не становится дополнительным источником `merge`. Ресиверы остаются в исходном графе, а их результаты обрабатываются в namespace. У обычных вызовов W/E-правила сохраняются и после группировки. У операндов действует отдельное условие: слева написана безымянная Structure, а единственный правый аргумент — ещё одна написанная безымянная Structure. Тогда ровно один внешний уровень снимается только справа; левая группа остаётся целой, повторного раскрытия и снятия в P0 нет. [Копирование, композиция и группировка][S]

## Сводная таблица

[Excel с формулами](LMX_Comparison_19-23.xlsx) · [PDF](LMX_Comparison_19-23.pdf)

Измерены непробельные символы основного прикладного листинга, включая объявления, импорты, необходимые оболочки и demo. Внешний запуск, main, печать, тесты и runtime не включены. Имена не нормализованы; Python без необязательных аннотаций. Отношения вычислены из сумм, а не как среднее отношений по отдельным шаблонам. Отдельный поясняющий шаблон ядра в Interpreter исключён; строка его использования через `copy` включена.

| Язык | Всего непробельных символов, 19–23 | К размеру LMX |
|---|---:|---:|
| LMX | 1389 | 1,00× |
| Python | 1627 | 1,17× |
| Java | 1970 | 1,42× |
| C++ | 1778 | 1,28× |
| C# | 2144 | 1,54× |
| TypeScript | 1957 | 1,41× |
| Go | 1848 | 1,33× |
| Rust | 2165 | 1,56× |

## 19. Singleton — Одиночка

Один провайдер повторно выдаёт ссылки на один и тот же объект настроек.

```lmx
Settings:
    int: value 0
    return: @
    get:
        return: Settings

Demo:
    return: int
    run:
        @: first Settings\get()
        @: second Settings\get()
        first\value := 7
        return: second\value
```

**Вызов:** `Demo\run()`. **Ожидаемый результат: 7.**

Оба вызова get возвращают тот же Settings. Прямая запись first\value меняет его поле, поэтому second\value читает 7. Каждый demo явно записывает 7, так что повторный запуск даёт тот же результат. Проверка дополнительно меняет поле через вторую ссылку и читает его через первую.

Область уникальности — один провайдер в одном последовательном контексте; для LMX это один Message. Это пример единственного предоставляемого объекта, а не запрет пользователю намеренно создать или скопировать другой объект. Межпроцессная уникальность и конкурентная инициализация не входят в сценарий. В Rust контекст представлен thread_local; клонируется Rc-ссылка, а не Settings, и Cell даёт изменяемое скалярное поле без блокировок. Остальные программы также рассматриваются только в одном последовательном контексте.

**LMX: 141** непробельных символов. [Сравнение на восьми языках](19_singleton_comparison.md).

[Refactoring.Guru — Singleton](https://refactoring.guru/design-patterns/singleton) · [Refactoring.Guru — Singleton in Python](https://refactoring.guru/design-patterns/singleton/python/example)

## 20. Abstract Factory — Абстрактная фабрика

Один потребитель получает два согласованных продукта от выбранного семейства фабрики.

<!-- counted-lmx: primary -->
```lmx
Button:
    int: value
    return: int
    render:
        return: value

Frame:
    int: value
    @: button
    return: int
    render:
        return: value + button\render()

Light:
    return: @
    button:
        return: derive(Button; (int: value 1))
    frame:
        return: derive(Frame; (int: value 10))

Dark:
    return: @
    button:
        return: derive(Button; (int: value 2))
    frame:
        return: derive(Frame; (int: value 20))

Client:
    @: factory
    return: int
    render:
        @: button factory\button()
        @: frame factory\frame()
        return: frame\render()
    demo:
        return: render(factory := Light) + render(factory := Dark)
```

Фабричные методы явно группируют поток `merge` перед возвратом одного продукта. DATA самой фабрики не является источником этой композиции.

**Вызов:** `Client\demo()`. **Ожидаемый результат: 33.**

Client\render(factory := Light) получает кнопку 1 и рамку 10, затем Frame.render вызывает Button.render и возвращает 11. Тот же Client\render(factory := Dark) получает 2 и 20 и возвращает 22. Семейство выбирается одним аргументом фабрики, оба продукта создаются через неё. Повторные вызовы фабричных методов создают отдельные продукты.

Два семейства конфигураций и два вида продуктов; совместимость семейства обеспечена выбранной фабрикой и порядком действий потребителя. Продукты имеют общий формат и различаются настройками: для этого сценария отдельные подклассы LightButton/DarkButton не нужны. Никакой язык здесь не запрещает вручную смешать продукты двух семейств. Это не сравнение GUI-библиотек или автоматического доказательства совместимости. C++ выражает интерфейс фабрики двумя указателями на функции, сохраняя тот же выбор семейства во время выполнения.

**LMX: 458** непробельных символов. [Сравнение на восьми языках](20_abstract_factory_comparison.md).

[Refactoring.Guru — Abstract Factory](https://refactoring.guru/design-patterns/abstract-factory) · [Refactoring.Guru — Abstract Factory in Python](https://refactoring.guru/design-patterns/abstract-factory/python/example)

Прямой derive уже входит в текущее ядро и заменяет ту же композицию merge. Все поля и обе семьи сохранены. Процедурный аналог на том же ядре приведён ниже, полный исходник ресивера — в сравнении.

### Процедурный аналог — вне основного подсчёта

<!-- uncounted-lmx: alternative -->
```lmx
Button:
    int: value
    return: int
    render:
        return: value

Frame:
    int: value
    @: button
    return: int
    render:
        return: value + button\render()

Light:
    return: @
    button:
        return: (merge(Button; (int: value 1)))
    frame:
        return: (merge(Frame; (int: value 10)))

Dark:
    return: @
    button:
        return: (merge(Button; (int: value 2)))
    frame:
        return: (merge(Frame; (int: value 20)))

Client:
    @: factory
    return: int
    render:
        @: button factory\button()
        @: frame factory\frame()
        return: frame\render()
    demo:
        return: render(factory := Light) + render(factory := Dark)
```

## 21. Flyweight — общее состояние глифов

Повторные запросы вида возвращают один общий объект, а каждое использование передаёт собственное внешнее состояние.

<!-- counted-lmx: primary -->
```lmx
glyphs:
    int: kind
    return: @
    immutable: thin: int: width 2
    immutable: thick: int: width 3
    get:
        if: kind = 0
            return: thin
        return: thick
    drawing:
        @: glyph
        int: position
        return: int
        render:
            return: glyph\width * 10 + position
        demo:
            @: first get(0)
            @: second get(0)
            @: third get(1)
            return: render(first 3) + render(second 7) + render(third 1)
```

**Вызов:** `glyphs\drawing\demo()`. **Ожидаемый результат: 81.**

`first` и `second` ссылаются на один `thin`, `third` — на другой объект `thick`. `render` читает именованное поле `width`, а позицию получает отдельно: `23 + 27 + 31 = 81`. В Python используется та же модель именованного поля — `@dataclass(frozen=True)` с `width: int`, а не одноэлементный tuple.

`drawing` вложена в `glyphs`, поэтому `get` виден лексически. DATA методов `render` и `demo` — `drawing`, DATA метода `get` — `glyphs`. Внутри корневого блока нет пустых строк. Завершающий `return` на уровне объявления `demo` завершает его тело; `render(first 3)` передаёт два позиционных аргумента.

`immutable` защищает общую ширину от изменения; const-имя само по себе не означает неизменяемость содержимого. Во всех восьми версиях пул заранее содержит два глифа. Динамического кэша и вытеснения нет. Поле `width` представляет общий набор свойств, который может быть больше; пример показывает разделение состояния и идентичность, а не измеренный выигрыш памяти. В Go неизменяемость общих данных остаётся контрактом API.

**LMX: 281**, **Python: 309** непробельных символов. [Сравнение на восьми языках](21_flyweight_comparison.md).

[Refactoring.Guru — Flyweight in Python, conceptual example](https://refactoring.guru/design-patterns/flyweight/python/example)

Исправлен отступ последнего return: он принадлежит CODE demo. Непробельный размер не меняется. Прежний исходник сохранён ниже и исключён из подсчёта.

### Прежний вариант LMX — не входит в подсчёт символов

<!-- uncounted-lmx: procedural -->
```lmx
glyphs:
    int: kind
    return: @
    immutable: thin: int: width 2
    immutable: thick: int: width 3
    get:
        if: kind = 0
            return: thin
        return: thick
    drawing:
        @: glyph
        int: position
        return: int
        render:
            return: glyph\width * 10 + position
        demo:
            @: first get(0)
            @: second get(0)
            @: third get(1)
        return: render(first 3) + render(second 7) + render(third 1)
```

## 22. Mediator — согласование двух компонентов

Два компонента сообщают о своих действиях посреднику; только он определяет реакцию другого компонента.

```lmx
Room:
    control:
        int: enabled 0
        toggle:
            node\enabled := 1 - node\enabled
            notify(event := 1)
    ---
    fan:
        int: running 0
        stop:
            node\running := 0
            notify(event := 2)
    ---
    int: event
    notify:
        if: event = 1
            fan\running := control\enabled
        if: event = 2
            control\enabled := 0

Demo:
    return: int
    run:
        @: room (copy(Room))
        room\control\toggle()
        int: first room\fan\running
        room\fan\stop()
        return: first * 10 + room\control\enabled
```

**Вызов:** `Demo\run()`. **Ожидаемый результат: 10.**

После toggle оба флага равны 1, поэтому first = 1. Вызов stop обнуляет running, а посредник обнуляет enabled. Итог: 1 × 10 + 0 = 10. Обратная реакция показывает, что это двустороннее согласование через посредника.

Синхронный пример с двумя фиксированными компонентами и двумя событиями. Событие задаёт отправителя однозначно; общий реестр подписчиков не нужен. Прямые записи посредника не генерируют новых событий, поэтому цикл уведомлений не возникает. В Rust локальное замыкание посредника и Cell обеспечивают ту же связь без циклического владения. Копирование уже связанного C++ Room и перенос компонентов между посредниками не входят в сценарий.

**LMX: 350** непробельных символов. [Сравнение на восьми языках](22_mediator_comparison.md).

[Refactoring.Guru — Mediator in Python, conceptual example](https://refactoring.guru/design-patterns/mediator/python/example)

## 23. Interpreter — сохранённое выражение и пользовательский операнд

Одно сохранённое выражение `(x + 3) + x` вычисляется при двух значениях переменной. LMX хранит его в графе метода `calculate`, где переменная называется `n`; Python сохраняет ту же композицию в замыкании `tree`.

### Прикладной код — входит в подсчёт

<!-- counted-code: LMX -->
```lmx
operands:
    copy: sys\OPERANDS_TEMPLATE
    return: int
    add:
        return: \left + \right[0]
    example:
        int: n
        return: int
        calculate:
            return: (n add 3) add n
        demo:
            return: calculate(2) + calculate(5)
```

**Вызов:** `operands\example\demo()`. **Ожидаемый результат: 20.** Внешний вызов в подсчёт не входит.

`calculate(2)` вычисляет `(2 + 3) + 2 = 7`, `calculate(5)` — `(5 + 3) + 5 = 13`; `demo` складывает результаты. DATA этих двух методов — вложенная группа `example`. Метод `add` виден из неё лексически, поэтому отдельный `import` не нужен. DATA самого `add` — `operands`.

`copy: sys\OPERANDS_TEMPLATE` предоставляет общий заголовок операнда. `PASS_ARGS_AS_IS 0` означает передачу ссылок на подготовленные значения. `\left` читает левое значение, `\right[0]` — первое правое. Для внешнего `add` левое значение уже равно результату внутреннего. Имя операции совпадает с именем метода; отдельная регистрация в `sys\operand` не требуется. [Контракт операндов](../LMX_semantics.en.md#prepared-operands)

### Шаблон ядра — пояснение, исключённое из подсчёта

<!-- uncounted-code: kernel-reference -->
```lmx
sys:
    OPERANDS_TEMPLATE:
        @: left
        @[]: right
        const: int: PASS_ARGS_AS_IS 0
        const: int: PRIORITY priority("+")
```

В шаблоне общие ссылки `@`, а не ограничение аргументов типом `int`. Внутри `sys` метод приоритета доступен как `priority("+")`. Шаблон не задаёт `return`: конкретный результат объявлен один раз в прикладном `operands` как `return: int`. Поэтому не требуется подмена одноимённого DATA-объявления или специальное правило для `copy`.

В стоимость прикладного примера включена строка использования шаблона. Его определение относится к ядру и исключено так же, как внутренние реализации стандартных библиотек Python и других языков. Показать определение здесь нужно, чтобы было видно происхождение `left`, `right` и настроек.

Режим `PASS_ARGS_AS_IS 1` передаёт исходные вхождения с явным вычислением через `sys\eval`; этому примеру достаточно режима `0`. Разыменование `\` само по себе не вызывает код. Сравнение показывает сохранённую форму вычисления и два контекста её исполнения. Отдельный текстовый парсер, обход для печати и API построения произвольных деревьев во время выполнения в задачу не входят.

**LMX: 159** непробельных символов, **266** символов с пробелами/LF, **12** строк. **Python: 185** непробельных символов. В этой паре LMX короче по основной метрике на **14,05%**. [Сравнение на восьми языках](23_interpreter_comparison.md).

[GoF — Interpreter, intent, grammar, participants and sample code (MIT-hosted text)](https://people.csail.mit.edu/addy/pattern/pat5c.htm)

## Проверка

Листинги LMX буквально совпадают с отдельными файлами сравнения. Они согласованы с текущими правилами и уточнениями автора. Статус исполнения и проверки остальных языков указан в каждом сравнительном файле. Числа в Excel и PDF получены из этих же листингов.



[S]: ../LMX_semantics.en.md#merge-two-forms
