#include "log.h"
#include "printf.h"
#include "profile.h"
#include "tls.h"
#include "util.h"

#if MG_TLS == MG_TLS_MBED

#if defined(MBEDTLS_VERSION_NUMBER) && MBEDTLS_VERSION_NUMBER >= 0x03000000 && \
    MBEDTLS_VERSION_NUMBER < 0x04000000
#define MG_MBEDTLS_RNG_GET , mg_mbed_rng, NULL
#else
#define MG_MBEDTLS_RNG_GET
#endif

static int mg_tls_err(struct mg_connection *c, int rc) {
  char s[80];
  mbedtls_strerror(rc, s, sizeof(s));
  MG_ERROR(("%lu %s", ((struct mg_connection *) c)->id, s));
  return rc;
}

#if defined(MBEDTLS_VERSION_NUMBER) && MBEDTLS_VERSION_NUMBER >= 0x04000000
#else
static int mg_mbed_rng(void *ctx, unsigned char *buf, size_t len) {
  (void) ctx;
  return mg_random(buf, len) ? 0 : -1;
}
#endif

static int mg_load_cert(struct mg_str str, mbedtls_x509_crt *p) {
  if (str.buf == NULL || str.buf[0] == '\0' || str.buf[0] == '*') return 0;
  if (!MG_IS_DER(str.buf)) str.len++;  // PEM, include trailing NUL
  return mbedtls_x509_crt_parse(p, (uint8_t *) str.buf, str.len);
}

static int mg_load_key(struct mg_str str, mbedtls_pk_context *p) {
  if (str.buf == NULL || str.buf[0] == '\0' || str.buf[0] == '*') return 0;
  if (!MG_IS_DER(str.buf)) str.len++;  // PEM, include trailing NUL
  return mbedtls_pk_parse_key(p, (uint8_t *) str.buf, str.len, NULL,
                              0 MG_MBEDTLS_RNG_GET);
}

void mg_tls_free(struct mg_connection *c) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  if (tls != NULL) {
    mbedtls_ssl_free(&tls->ssl);
    mbedtls_pk_free(&tls->pk);
    mbedtls_x509_crt_free(&tls->ca);
    mbedtls_x509_crt_free(&tls->cert);
    mbedtls_ssl_config_free(&tls->conf);
#ifdef MBEDTLS_SSL_SESSION_TICKETS
    mbedtls_ssl_ticket_free(&tls->ticket);
#endif
    // PSA has global data. Do not call mbedtls_psa_crypto_free() here,
    // it will free all global resources. Call it when actually freeing all
    // application resources (main() exits)
    mg_free(tls);
    c->tls = NULL;
  }
}

static int mg_net_send(void *ctx, const unsigned char *buf, size_t len) {
  long n = mg_io_send((struct mg_connection *) ctx, buf, len);
  MG_VERBOSE(("%lu n=%ld e=%d", ((struct mg_connection *) ctx)->id, n, errno));
  if (n == MG_IO_WAIT) return MBEDTLS_ERR_SSL_WANT_WRITE;
  // if (n == MG_IO_RESET) return MBEDTLS_ERR_NET_CONN_RESET;
  if (n == MG_IO_ERR) return MBEDTLS_ERR_NET_SEND_FAILED;
  return (int) n;
}

static int mg_net_recv(void *ctx, unsigned char *buf, size_t len) {
  long n = mg_io_recv((struct mg_connection *) ctx, buf, len);
  MG_VERBOSE(("%lu n=%ld", ((struct mg_connection *) ctx)->id, n));
  if (n == MG_IO_WAIT) return MBEDTLS_ERR_SSL_WANT_READ;
  // if (n == MG_IO_RESET) return MBEDTLS_ERR_NET_CONN_RESET;
  if (n == MG_IO_ERR) return MBEDTLS_ERR_NET_RECV_FAILED;
  return (int) n;
}

void mg_tls_handshake(struct mg_connection *c) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  int rc = mbedtls_ssl_handshake(&tls->ssl);
  if (rc == 0) {  // Success
    if (tls->check_name && (mbedtls_ssl_get_verify_result(&tls->ssl) &
                            MBEDTLS_X509_BADCERT_CN_MISMATCH)) {
      mg_error(c, "failed to verify hostname");
      return;
    } // ignore MBEDTLS_X509_BADCERT_NOT_TRUSTED, no CA cert given
    MG_DEBUG(("%lu success", c->id));
    c->is_tls_hs = 0;
    mg_call(c, MG_EV_TLS_HS, NULL);
  } else if (rc == MBEDTLS_ERR_SSL_WANT_READ ||
             rc == MBEDTLS_ERR_SSL_WANT_WRITE) {  // Still pending
    MG_VERBOSE(("%lu pending, %d%d %d (-%#x)", c->id, c->is_connecting,
                c->is_tls_hs, rc, -rc));
  } else {
    mg_error(c, "TLS handshake: -%#x", -mg_tls_err(c, rc));  // Error
  }
}

static void debug_cb(void *c, int lev, const char *s, int n, const char *s2) {
  n = (int) strlen(s2) - 1;
  MG_INFO(("%lu %d %.*s", ((struct mg_connection *) c)->id, lev, n, s2));
  (void) s;
}

void mg_tls_init(struct mg_connection *c, const struct mg_tls_opts *opts) {
  struct mg_tls *tls = (struct mg_tls *) mg_calloc(1, sizeof(*tls));
  int rc = 0;
  bool check_name = false;
  c->tls = tls;
  if (c->tls == NULL) {
    mg_error(c, "TLS OOM");
    goto fail;
  }
  MG_DEBUG(("%lu Setting TLS", c->id));
  MG_PROF_ADD(c, "mbedtls_init_start");
  mbedtls_ssl_init(&tls->ssl);
  mbedtls_ssl_config_init(&tls->conf);
  mbedtls_x509_crt_init(&tls->ca);
  mbedtls_x509_crt_init(&tls->cert);
  mbedtls_pk_init(&tls->pk);
  mbedtls_ssl_conf_dbg(&tls->conf, debug_cb, c);
#if defined(MG_MBEDTLS_DEBUG_LEVEL)
  mbedtls_debug_set_threshold(MG_MBEDTLS_DEBUG_LEVEL);
#endif
  if ((rc = mbedtls_ssl_config_defaults(
           &tls->conf,
           c->is_client ? MBEDTLS_SSL_IS_CLIENT : MBEDTLS_SSL_IS_SERVER,
           MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT)) != 0) {
    mg_error(c, "tls defaults %#x", -mg_tls_err(c, rc));
    goto fail;
  }
#if defined(MBEDTLS_VERSION_NUMBER) && MBEDTLS_VERSION_NUMBER >= 0x04000000
  MG_INFO(("PSA is in control of random number generation"));
#else
  mbedtls_ssl_conf_rng(&tls->conf, mg_mbed_rng, c);
#endif

  if (c->is_client && opts->name.buf != NULL && opts->name.len > 0 &&
      opts->name.buf[0] != '\0') {
    char *host = mg_mprintf("%.*s", opts->name.len, opts->name.buf);
    mbedtls_ssl_set_hostname(&tls->ssl, host);
#if !defined(MBEDTLS_VERSION_NUMBER) || MBEDTLS_VERSION_NUMBER < 0x03030000 || \
    MBEDTLS_VERSION_NUMBER >= 0x04000000
    // NOTE: MBEDTLS_SSL_VERIFY_OPTIONAL is not supported for TLS1.3 on client
    // side See https://github.com/Mbed-TLS/mbedtls/issues/7075
    check_name = true;
#endif
    MG_DEBUG(("%lu hostname verification: %s", c->id, host));
    mg_free(host);
  } else {
    MG_DEBUG(("%lu skipping hostname verification", c->id));
    mbedtls_ssl_set_hostname(&tls->ssl, NULL);
  }
  if (opts->ca.len == 0 || mg_strcmp(opts->ca, mg_str("*")) == 0) {
    mbedtls_ssl_conf_authmode(&tls->conf, check_name  // see set comment above
                                              ? MBEDTLS_SSL_VERIFY_OPTIONAL
                                              : MBEDTLS_SSL_VERIFY_NONE);
    tls->check_name = check_name; // host name set but no CA cert given
  } else {
    if ((rc = mg_load_cert(opts->ca, &tls->ca)) != 0) {
      mg_error(c, "CA err %#x", -mg_tls_err(c, rc));
      goto fail;
    }
    mbedtls_ssl_conf_ca_chain(&tls->conf, &tls->ca, NULL);
    mbedtls_ssl_conf_authmode(&tls->conf, MBEDTLS_SSL_VERIFY_REQUIRED);
  }
  if ((rc = mg_load_cert(opts->cert, &tls->cert)) != 0) {
    mg_error(c, "CERT err %#x", -mg_tls_err(c, rc));
    goto fail;
  }
  if ((rc = mg_load_key(opts->key, &tls->pk)) != 0) {
    mg_error(c, "Key err %#x", -mg_tls_err(c, rc));
    goto fail;
  }
  if (tls->cert.version &&
      (rc = mbedtls_ssl_conf_own_cert(&tls->conf, &tls->cert, &tls->pk)) != 0) {
    mg_error(c, "own CERT %#x", -mg_tls_err(c, rc));
    goto fail;
  }

#ifdef MBEDTLS_SSL_SESSION_TICKETS
  if (!c->is_client && c->mgr->tls_ctx != NULL) {
    mbedtls_ssl_conf_session_tickets_cb(
        &tls->conf, mbedtls_ssl_ticket_write, mbedtls_ssl_ticket_parse,
        &((struct mg_tls_ctx *) c->mgr->tls_ctx)->tickets);
  }
#endif

  if ((rc = mbedtls_ssl_setup(&tls->ssl, &tls->conf)) != 0) {
    mg_error(c, "setup err %#x", -mg_tls_err(c, rc));
    goto fail;
  }
  c->is_tls = 1;
  c->is_tls_hs = 1;
  mbedtls_ssl_set_bio(&tls->ssl, c, mg_net_send, mg_net_recv, 0);
  MG_PROF_ADD(c, "mbedtls_init_end");
  return;
fail:
  mg_tls_free(c);
}

size_t mg_tls_pending(struct mg_connection *c) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  return tls == NULL ? 0 : mbedtls_ssl_get_bytes_avail(&tls->ssl);
}

long mg_tls_recv(struct mg_connection *c, void *buf, size_t len) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  long n = mbedtls_ssl_read(&tls->ssl, (unsigned char *) buf, len);
  if (!c->is_tls_hs && (buf == NULL || len == 0) && n == 0) return 0;  // MIP
  if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE)
    return MG_IO_WAIT;
#if defined(MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET)
  if (n == MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET) {
    return MG_IO_WAIT;
  }
#endif
  if (n <= 0) return MG_IO_ERR;
  return n;
}

long mg_tls_send(struct mg_connection *c, const void *buf, size_t len) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  long n;
  bool was_throttled = c->is_tls_throttled;  // see #3074
  n = was_throttled ? mbedtls_ssl_write(&tls->ssl, tls->throttled_buf,
                                        tls->throttled_len) /* flush old data */
                    : mbedtls_ssl_write(&tls->ssl, (unsigned char *) buf,
                                        len);  // encrypt current data
#if defined(MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET)
  if (n == MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET)
    return MG_IO_WAIT;
#endif
  c->is_tls_throttled =
      (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE);
  if (was_throttled && c->is_tls_throttled) return MG_IO_WAIT;  // no changes
  if (c->is_tls_throttled) {
    tls->throttled_buf =
        (unsigned char *) buf;  // MbedTLS code actually ignores
    tls->throttled_len = len;   // these, but let's play API rules
    return MG_IO_WAIT;
  }
  if (n <= 0) return MG_IO_ERR;
  return n;
}

long mg_tls_flush(struct mg_connection *c) {
  struct mg_tls *tls = (struct mg_tls *) c->tls;
  long n = 0;
  if (c->is_tls_throttled && c->is_draining) {
    n = mbedtls_ssl_write(&tls->ssl, tls->throttled_buf, tls->throttled_len);
#if defined(MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET)
    if (n == MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET) return MG_IO_WAIT;
#endif
    c->is_tls_throttled =
        (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE);
    if (c->is_tls_throttled) return MG_IO_WAIT;
    if (n <= 0) return MG_IO_ERR;
  }
  return 0;
}

void mg_tls_ctx_init(struct mg_mgr *mgr) {
#if defined(MBEDTLS_VERSION_NUMBER) && MBEDTLS_VERSION_NUMBER >= 0x03000000 && \
    defined(MBEDTLS_PSA_CRYPTO_C)
  psa_crypto_init();  // Initializes global PSA resources, no-op if already done
#endif
#ifdef MBEDTLS_SSL_SESSION_TICKETS
  {
    struct mg_tls_ctx *ctx = (struct mg_tls_ctx *) mg_calloc(1, sizeof(*ctx));
    if (ctx == NULL) {
      MG_ERROR(("TLS context init OOM"));
    } else {
      int rc;
      mbedtls_ssl_ticket_init(&ctx->tickets);
#if defined(MBEDTLS_VERSION_NUMBER) && MBEDTLS_VERSION_NUMBER >= 0x04000000
      rc = mbedtls_ssl_ticket_setup(&ctx->tickets, PSA_ALG_GCM,
                                    PSA_KEY_TYPE_AES, 128, 86400);
#else
      rc = mbedtls_ssl_ticket_setup(&ctx->tickets, mg_mbed_rng, NULL,
                                         MBEDTLS_CIPHER_AES_128_GCM, 86400);
#endif
      if (rc != 0) {
        MG_ERROR((" mbedtls_ssl_ticket_setup %#x", -rc));
        mbedtls_ssl_ticket_free(&ctx->tickets);
        mg_free(ctx);
      } else {
        mgr->tls_ctx = ctx;
      }
    }
  }
#else
  (void) mgr;
#endif
}

void mg_tls_ctx_free(struct mg_mgr *mgr) {
  struct mg_tls_ctx *ctx = (struct mg_tls_ctx *) mgr->tls_ctx;
  if (ctx != NULL) {
#ifdef MBEDTLS_SSL_SESSION_TICKETS
    mbedtls_ssl_ticket_free(&ctx->tickets);
#endif
    mg_free(ctx);
    mgr->tls_ctx = NULL;
  }
}
#endif
